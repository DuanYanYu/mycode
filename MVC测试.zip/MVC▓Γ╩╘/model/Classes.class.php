<?php		  

class Classes{
  private $classId;
  private $className;
  private $major;
  private $direction;
 
  public function __set($name, $value) {
     $this->$name = $value;
  }

  public function __get($name) {
    return isset($this->$name) ? $this->$name : null;
  }
  
}