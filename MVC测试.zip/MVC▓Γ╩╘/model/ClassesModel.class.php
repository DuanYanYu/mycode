<?php		  
/**
 * 文件名:
 * 描述：
 * 作者：
 * 时间：
 * 版权：济南洋洋信息技术有限公司
 * 版本号：
 */
require_once('../../public/Db.class.php');
/*require_once('Classes.class.php');*/
class ClassesModel {
	/**
	 *函数名：
	 *功能：获取全部班级信息
	 *参数：
	 *返回值:
	 */
	public function getClasses() {
		$db = Db::getInstance();
		$sql = "SELECT * FROM t_class ORDER BY classId";
		$arrayClasses = $db->dql($sql);
		$db->close();
		return $arrayClasses;
	}	

	/**
	 *函数名：
	 *功能：
	 *参数：
	 *返回值:
	 */
	public function getClassesByClassId($classId){
		$db = Db::getInstance();
		$sql = "SELECT * FROM t_class WHERE classId='$classId'";
		$arrayClasses = $db->dql($sql);
		$db->close();
		return $arrayClasses[0];
	}	
	/* *函数名：
	 *功能：
	 *参数：
	 *返回值:
	 */
	public function classesAdd($classes){
		$db = Db::getInstance();
		$classId = $classes->classId;
		$className = $classes->className;
		$major = $classes->major;
		$direction = $classes->direction;
		$sql = "INSERT INTO t_class (classId,className,major,direction) VALUES ($classId,'$className','$major','$direction')";
		$result= $db->dml($sql);
		$db->close();
		return $result;
	}
	/**
	 *函数名：
	 *功能：
	 *参数：
	 *返回值:
	 */
	public function classesEdit($classes){
		$db = Db::getInstance();
		$classId = $classes->classId;
		$className = $classes->className;
		$major = $classes->major;
		$direction = $classes->direction;
		$sql = "UPDATE t_class SET className = '$className',major = '$major',direction = '$direction'		 
		WHERE classId = '$classId'";
 		$result = $db->dml($sql);
		$db->close();
		 return $result;
	}
	/**
	 *函数名：
	 *功能：
	 *参数：
	 *返回值:
	 */
	public function classesDel($classId) {
		$db = Db::getInstance();
		$sql = "DELETE FROM `t_class` WHERE(`classId` = $classId)";
		$result = $db->dml($sql);
		$db->close();
		return $result;
	}
	/**
	*函数名: getClassByPage
	*功能:查询所有班级
	*参数: $page
	*返回值:
	*/
	public function getClassesByPage($page) {
		$db = Db::getInstance();
		$start = ($page->getPageId()-1)*($page->getPageSize());//求出前面已经显示了多少条数据
		$pageSize = $page->getPageSize();
		$sql1 = "SELECT * FROM t_class ORDER BY classId LIMIT $start, $pageSize";
		$sql2 = "SELECT COUNT(*) FROM t_class";
		$db->execute_dql_page($sql1, $sql2, $page);
		$db->close();
	}

}