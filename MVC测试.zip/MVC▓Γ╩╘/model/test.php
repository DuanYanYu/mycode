<?php
require __DIR__ . '/Classes.class.php';
$classes = new Classes();
$classes->className='123';
echo $classes->className;