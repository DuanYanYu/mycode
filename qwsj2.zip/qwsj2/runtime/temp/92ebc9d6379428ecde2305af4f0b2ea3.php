<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"D:\webroot\qwsj2\public/../application/index\view\index\index.html";i:1581685773;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<title>权威数据</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- 引入 Bootstrap -->
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/public/static/css/style.css"/>
		<link rel="stylesheet" href="/public/static/css/bootstrap-datetimepicker.css">
		<link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
    </head>
	<body>
		<div class="container">
			<div class="row clearfix">
			<div class="col-md-offset-3 col-md-6 colum">
				<table class="table table-bordered table-hover">
					<caption class="text-center">权威数据</caption>
					<tr >
						<th>数据标题</th>
						<th>数据地址</th>
						<th>数据日期</th>
						<th class="text-center">操作</th>
					</tr>
					<?php if(is_array($datas) || $datas instanceof \think\Collection || $datas instanceof \think\Paginator): $i = 0; $__LIST__ = $datas;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?>
					<tr>
						<td><?php echo $data['data_title']; ?></td>
						<td><?php echo $data['data_web']; ?></td>
						<td><?php echo $data['data_date']; ?></td>
						<td class="text-center">
							<i class="fa fa-edit"></i>
							<a href="<?php echo url('dataEdit', ['data_id'=>$data['data_id']]); ?>">修改</a>
							<i class="fa fa-trash"></i>
							<a href="<?php echo url('dataDelete', ['dataId'=>$data['data_id']]); ?>"
							   onclick="return confirm('确认要删除吗？')">删除</a>
						</td>
					</tr>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</table>
			</div>
			<div class="col-md-offset-3 col-md-6 text-right">
				<i class="fa fa-plus"></i>
				<a href="<?php echo url('dataAdd'); ?>">添加</a>
			</div>
			<div class="col-md-offset-3 col-md-6 colum">
				<div class="pagination pull-right">
					<?php echo $datas->render(); ?>
				</div>
			</div>
		</div>
		</div>
		
		<!-- jQuery (Bootstrap 的 JavaScript 插件需要引入 jQuery) -->
		<script src="https://code.jquery.com/jquery.js"></script>
		<!-- 包括所有已编译的插件 -->
		<script src="js/bootstrap.min.js"></script>
		<script src="/public/static/js/bootstrap-datetimepicker.js"></script>
		<script src="/public/static/js/bootstrap-datetimepicker.zh-CN.js"></script>
	</body>
</html>