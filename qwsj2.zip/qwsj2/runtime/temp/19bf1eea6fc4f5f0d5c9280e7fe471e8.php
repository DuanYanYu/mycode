<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"D:\webroot\qwsj2\public/../application/index\view\index\data_edit.html";i:1581746994;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>数据修改表</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入 Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <script src="/public/static/js/laydate/laydate.js"></script>
    <link rel="stylesheet" type="text/css" href="/public/static/css/style.css">
		<link rel="stylesheet" href="/public/static/css/bootstrap-datetimepicker.css">
		
</head>
<body>
    <div class="container">
        <div class="col-md-offset-4 col-md-4 colum">
            <form method="post">
                <table class="table table-bordered table-hover">
                    <caption class="text-center">修改数据</caption>
                    <tbody>
                    <tr>
                        <td style="text-align: right">标题</td>
                        <td>
                            <input type="text" name="data_title" id="data_title" value="<?php echo $data['data_title']; ?>"/>&nbsp;&nbsp;
                            <span style="color: red">*不能为空</span>
                        </td>
                    </tr>
                    <tr>
                        <td style="text-align: right">网页</td>
                        <td>
                            <input type="text" name="data_web" id="data_web" value="<?php echo $data['data_web']; ?>"/>&nbsp;&nbsp;
                            <span style="color: red">*不能为空</span>
                        </td>
                    </tr>
                    <tr>
                        <td style="text-align: right" >日期</td>
                        <td>
                            <input type="text" name="data_date" id="data_date" value="<?php echo $data['data_date']; ?>" autocomplete="off"/>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <div class="row clearfix text-center">
                    <input type="submit" value="保存" >
                    <input type="button" value="返回" onclick="window.history.back()">
                </div>
            </form>
        </div>
    </div>
    <!-- jQuery (Bootstrap 的 JavaScript 插件需要引入 jQuery) -->
    <script src="https://code.jquery.com/jquery.js"></script>
		<script src="/public/static/js/bootstrap-datetimepicker.js"></script>
		<script src="/public/static/js/bootstrap-datetimepicker.zh-CN.js"></script>
    <!-- 包括所有已编译的插件 -->
    <script src="js/bootstrap.min.js"></script>
		<script>
			$('#data_date').datetimepicker({
				bootcssVer:3,
				language: 'zh-CN',//显示中文
				format: 'yyyy年mm月dd日 ',//显示格式
				minView: "month",//设置只显示到月份
				initialDate: new Date(),
				autoclose: true,//选中自动关闭
				todayBtn: false,//显示今日按钮*/
			});
		</script>
</body>
</html>