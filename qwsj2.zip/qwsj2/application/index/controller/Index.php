<?php
namespace app\index\controller;

use think\Db;
use think\Controller;
use think\Request;

class Index extends Controller
{
    /**
     * 展示信息
     * @param
     * @return 页面 index.html页面
     */
    public function index()
    {
		$datas = Db::table('exam_data')->where('state', 1)->paginate(5);
//		echo '<pre>';
//		print_r($datas);
//		foreach ($datas as $data) {
//		    print_r($data);
//		    dump($data);
//            gettype($data['data_date']);
//            exit();
//        }
//		$datas = array_map(function ($data) {
////            $data['data_date'] = substr_replace($data['data_date']->scalar, '年', 4,1);
////            $data['data_date'] = substr_replace($data['data_date']->scalar, '月', 9,1);
////            $data['data_date'] = substr_replace($data['data_date']->scalar, '日', 14,1);
//         }, $datas);
//		dump($datas);
//		exit();
		$this->assign("datas", $datas);
		return $this->fetch();
    }

    /**
     * 添加数据
     * @param
     * @return 页面 显示添加数据的页面
     */
	public function dataAdd()
	{
		if (Request::instance()->isPost()) {
            $data = Request::instance()->param();
            $data['data_date'] = substr_replace($data['data_date'], '-', 4,3);
            $data['data_date'] = substr_replace($data['data_date'], '-', 7,3);
            $data['data_date'] = substr_replace($data['data_date'], '', 10,3);
            if ($data['data_date'] == '') {
                $data['data_date'] = null;
            }
			$result = Db::table('exam_data')->insert($data);
			if ($result == true) {
				$this->success('数据添加成功！', url('index'),'');
			} else {
				$this->error('数据案添加失败！');
			}
		} else {
			return $this->fetch();
		}
	}

    /**
     * 修改数据
     * @param
     * @return 页面 显示修改数据的页面
     */
	public function dataEdit()
    {
        $dataId = Request::instance()->param('data_id');
        if (Request::instance()->isPost()) {
            $data = Request::instance()->param();
            if ($data['data_date'] == '') {
                $data['data_date'] = null;
            }
            $data['data_date'] = substr_replace($data['data_date'], '-', 4,3);
            $data['data_date'] = substr_replace($data['data_date'], '-', 7,3);
            $data['data_date'] = substr_replace($data['data_date'], '', 10,3);
            $result = Db::table('exam_data')->where('data_id', $dataId)->update($data);
            if ($result == true) {
                $this->success('修改成功！', url('index'));
//                return;
            } else {
                $this->error('修改失败！');
            }
        } else {
            $data = Db::table('exam_data')->where('data_id', $dataId)->find();
            $data['data_date'] = substr_replace($data['data_date'], '年', 4,1);
            $data['data_date'] = substr_replace($data['data_date'], '月', 9,1);
            $data['data_date'] = substr_replace($data['data_date'], '日', 14,1);
            $this->assign('data', $data);
            return $this->fetch();
        }
    }

    /**
     * 删除数据
     * @param
     * @return 页面 显示成功或失败的信息
     */
    public function dataDelete()
    {
        $dataId = Request::instance()->param('dataId');
        $data = array(
            'state' => 0,
        );
        $result = Db::table('exam_data')->where('data_id', $dataId)->update($data);
        if ($result == true) {
            $this->success('删除成功！', url('index'),'',1);
//            return;
        } else {
            $this->error('删除失败！');
        }
    }
}
